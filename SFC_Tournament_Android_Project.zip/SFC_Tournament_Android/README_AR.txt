SFC TOURNAMENT - مشروع Android

هذا مشروع Android Studio يحتوي على نسخة HTML المعدلة داخل التطبيق، ويشغلها في WebView مع تفعيل JavaScript والتخزين المحلي واختيار صور اللاعبين.

لبناء APK:
1) ثبّت Android Studio على كمبيوتر.
2) افتح مجلد SFC_Tournament_Android من Android Studio.
3) انتظر Gradle Sync، وثبّت Android SDK Platform 35 إذا طُلب ذلك.
4) من القائمة اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
5) بعد نجاح البناء اضغط Locate للوصول إلى ملف app-debug.apk.
6) انقل APK إلى الهاتف وثبّته. قد يطلب Android السماح بالتثبيت من هذا المصدر.

ملاحظة: هذا الملف مشروع مصدر جاهز للبناء، وليس APK مثبتاً أو مبنياً بالفعل. يلزم Android Studio وAndroid SDK لإنتاج APK.
